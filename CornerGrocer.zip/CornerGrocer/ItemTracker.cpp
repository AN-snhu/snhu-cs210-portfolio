#include "ItemTracker.h"
#include <cctype>
#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

// Read input file, populate the map, and create the backup file
ItemTracker::ItemTracker(const string& inputFileName) {
    ifstream inFS(inputFileName);
    string item;

    // Check if file opened successfully
    if (!inFS.is_open()) {
        cout << "Error: Could not open " << inputFileName << ". Please check the file path." << endl;
        return;
    }

    // Read each word until the end
    while (inFS >> item) {
        itemFrequencies[item]++;
    }

    inFS.close();

    // Generate backup file
    backupData();
}

// Writes map contents to frequency.dat
void ItemTracker::backupData() {
    ofstream outFS("frequency.dat");

    // verify permission to write the file
    if (!outFS.is_open()) {
        cout << "Error: Could not create backup file frequency.dat." << endl;
        return;
    }

    // Run through the map and write to the file
    for (auto const& pair : itemFrequencies) {
        outFS << pair.first << " " << pair.second << endl;
    }

    outFS.close();
}

// Menu Option 1: Return frequency for a specific word
int ItemTracker::getItemFrequency(const string& item) {
    // Create a copy of the input to format it
    string formattedItem = item;
    
    // Capitalize the first letter and lowercase all otyher letters
    if (!formattedItem.empty()) {
        formattedItem[0] = toupper(formattedItem[0]);
        for (size_t i = 1; i < formattedItem.length(); ++i) {
            formattedItem[i] = tolower(formattedItem[i]);
        }
    }

    // check if the key exists
    if (itemFrequencies.count(formattedItem) > 0) {
        return itemFrequencies[formattedItem];
    }
    return 0;
}

// Menu Option 2: Print all frequencies
void ItemTracker::printAllFrequencies() {
    cout << "\n--- Item Frequencies ---" << endl;
    for (auto const& pair : itemFrequencies) {
        cout << pair.first << " " << pair.second << endl;
    }
    cout << "------------------------\n" << endl;
}

// Menu Option 3: Print chart
void ItemTracker::printChart() {
    cout << "\n--- Histogram ---" << endl;
    for (auto const& pair : itemFrequencies) {
        // !!!FIX!!! Dont forget to print item name and align to the left
        cout << setw(15) << left << pair.first << " ";
        
        // Print * for each count of the item
        for (int i = 0; i < pair.second; ++i) {
            cout << "*";
        }
        cout << endl;
    }
    cout << "----------------------\n" << endl;
}
// Menu Option 5: Print the Py generated report
void ItemTracker::printPythonReport() {
    cout << "\n--- Launching Python End-of-Day Report ---" << endl;
    
    int result = system("python report_generator.py");
    
    if (result != 0) {
        system("python3 report_generator.py");
    }
}