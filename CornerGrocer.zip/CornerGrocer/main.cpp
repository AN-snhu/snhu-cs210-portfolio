#include <iostream>
#include <string>
#include "ItemTracker.h"

using namespace std;

// Display menu options
void displayMenu() {
    cout << "========== Corner Grocer ==========" << endl;
    cout << "1. Search for an item's frequency" << endl;
    cout << "2. Print all items and frequencies" << endl;
    cout << "3. Print Histogram" << endl;
    cout << "4. Exit program" << endl;
    cout << "5. Print Item Summary" << endl;
    cout << "===================================" << endl;
    cout << "Enter your choice (1-5): ";
}

int main() {
    // Instantiate ItemTracker object with the text file
    ItemTracker tracker("CS210_Project_Three_Input_File.txt");
    
    int choice = 0;
    string searchItem;

    // Main program loop runs until user selects option 4 
    while (choice != 4) {
        displayMenu();
        cin >> choice;

        // Check if user entered a non-integer
        if (cin.fail()) {
            cin.clear(); // Clear the error flag
            cin.ignore(10000, '\n'); // Discard invalid input in the buffer
            cout << "\nInvalid input. Please enter a number between 1 and 4.\n" << endl;
            continue;
        }

        // 4andle input choice
        switch (choice) {
            case 1:
                cout << "\nEnter the name of the item to search for: ";
                cin >> searchItem;
                cout << "\nFrequency of " << searchItem << ": " 
                     << tracker.getItemFrequency(searchItem) << "\n" << endl;
                break;
            case 2:
                tracker.printAllFrequencies();
                break;
            case 3:
                tracker.printChart();
                break;
            case 4:
                cout << "\nExiting program. Have a great day!" << endl;
                break;
            case 5:
                tracker.printPythonReport();
                break;
            default:
                cout << "\nInvalid option. Please choose a number between 1 and 5.\n" << endl;
                break;
        }
    }

    return 0;
}