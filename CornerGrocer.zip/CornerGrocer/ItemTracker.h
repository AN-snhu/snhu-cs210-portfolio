#ifndef ITEMTRACKER_H
#define ITEMTRACKER_H

#include <string>
#include <map>

class ItemTracker {
private:
    // Map to store the item name as the key and frequency as the value
    std::map<std::string, int> itemFrequencies;
    
    // Create the frequency.dat backup file
    void backupData(); 

public:
    // Takes input file name
    ItemTracker(const std::string& inputFileName);
    
    // Menu Option 1: Get specific item frequency
    int getItemFrequency(const std::string& item);
    
    // Menu Option 2: Print all items and their frequencies
    void printAllFrequencies();
    
    // Menu Option 3: Print Chart
    void printChart();

    // Menu Option 5: Print the Py report
    void printPythonReport();
};

#endif